function set_matlab_utils_path()

addpath('utils/');
addpath('utils/DMP_lib/');
addpath('utils/KalmanFilter_lib/');

end
